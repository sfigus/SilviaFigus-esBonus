package com.example.s.login_sfigus;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity_AccessoEffettuato extends AppCompatActivity
{
    String Password, Utente;
    String welcome = "Benvenuto " ;
    String error = "ACCESSO NEGATO";
    TextView user;
    @Override
    public boolean onSupportNavigateUp()
    {
        finish();
        return true;
    }
    protected void onCreate(Bundle savedInstanceState)
        {
            assert getSupportActionBar() != null;
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            setContentView(R.layout.activity__accesso_effettuato);
            super.onCreate(savedInstanceState);
            Intent intent = getIntent();
            String username = intent.getStringExtra("username");
            Password = intent.getStringExtra("password");


                if (username.equals("SailorMoon")&& Password.equals("Luna"))
                    {
                        user = (TextView) findViewById(R.id.username);
                        Utente = username;
                        user.setTextColor(Color.parseColor("#000000"));
                        user.setText(welcome + Utente);
                    }
                else
                    {
                        user = (TextView) findViewById(R.id.username);
                        user.setText(error);
                        user.setTextColor(Color.parseColor("#e21f1f"));
                    }
        }

    }


