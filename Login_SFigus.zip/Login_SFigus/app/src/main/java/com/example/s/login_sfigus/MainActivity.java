package com.example.s.login_sfigus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText Utente = (EditText) findViewById(R.id.username);
        final EditText Password = (EditText) findViewById(R.id.password);
        Button BottoneAccedi = (Button) findViewById(R.id.accedi);

        BottoneAccedi.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (Utente.getText().toString().isEmpty())
                    {
                        Utente.setError("Username vuoto");
                    }

                if(Password.getText().toString().isEmpty())
                    {
                        Password.setError("Password vuota");
                    }

                if(!(Utente.getText().toString().isEmpty()) &&!(Password.getText().toString().isEmpty()))
                    {
                     Intent AccessoEffettuato = new Intent(MainActivity.this,Activity_AccessoEffettuato.class);
                     AccessoEffettuato.putExtra("username", Utente.getText().toString());
                     AccessoEffettuato.putExtra("password", Password.getText().toString());
                     startActivity(AccessoEffettuato);
                    }
            }
        });
    }
}



